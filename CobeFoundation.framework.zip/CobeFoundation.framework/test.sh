#!/bin/bash -e

echo "********************"
echo "*    TESTING       *"
echo "********************"


sw_vers -productVersion

travis/scripts/xcbuild-safe.sh clean test -workspace $SCHEME.xcworkspace -scheme $SCHEME -destination 'platform=iOS Simulator,OS=10.3,id=43CD88FF-F754-4EA7-BB04-D879504B943B'



echo "****************"
echo "* testing done *"
echo "****************"
